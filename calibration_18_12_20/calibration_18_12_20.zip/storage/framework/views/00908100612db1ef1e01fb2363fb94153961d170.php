<?php $__env->startSection('content'); ?>
<div id="ribbon">
	<ol class="breadcrumb">
		<li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
		<li>Summary Report</li>
	</ol>
</div>
<div id="content">
	<section>
		<div class="row">
			<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="product-content product-wrap clearfix product-deatil">
					<div class="col-lg-12">
						<div class="row top-menu-box">
							<b>Summary Report</b>
						</div>
					</div>
					<?php
					$UserMaster=DB::table('usermaster')->where('IsActive',1)->select("UserId","UserName","UserEmail")->get();
					?>
					<div class="col-lg-12 mt20">
						<form name="frm" method="post" action="<?php echo e(url('/SummaryReportData')); ?>" target="_BLANK">
							<input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
							<div class="row">
								<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Calibration Method:</label>
										<select name="CalibrationId" class="form-control select2">
											<option value="0">--Select--</option>

											<?php
											$Calibration=DB::table('calibrationform')->where('IsActive',1)->get();
											?>
											<?php $__currentLoopData = $Calibration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cali): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($cali->RecId); ?>"><?php echo e($cali->Name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>
									</div>
								</div>
								<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Created By:</label>
										<select name="CreatedBy" class="form-control select2">
											<option value="0">--Select--</option>
											<?php $__currentLoopData = $UserMaster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($user->UserId); ?>"><?php echo e($user->UserName); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>
									</div>
								</div>
								<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Approved By:</label>
										<select name="ApprovedBy" class="form-control select2">
											<option value="0">--Select--</option>
											<?php $__currentLoopData = $UserMaster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($user->UserId); ?>"><?php echo e($user->UserName); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>
									</div>
								</div>
								<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Declined By:</label>
										<select name="DeclinedBy" class="form-control select2">
											<option value="0">--Select--</option>
											<?php $__currentLoopData = $UserMaster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($user->UserId); ?>"><?php echo e($user->UserName); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Date of Form Creation:</label>
										<div class="row">
											<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
												<input type="date" name="FromCreatedDate" class="form-control">
											</div>
											<div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
												<b>TO</b>
											</div>
											<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
												<input type="date" name="ToCreatedDate" class="form-control">
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Status:</label>
										<select name="Status" class="form-control select2">
											<option value="0">--Select--</option>

											<?php
											$StatusMaster=DB::table('statusmaster')->where('IsActive',1)->get();
											?>
											<?php $__currentLoopData = $StatusMaster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($Status->RecId); ?>"><?php echo e($Status->Name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>
									</div>
								</div>
								<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Submitted By:</label>
										<select name="SubmittedBy" class="form-control select2">
											<option value="0">--Select--</option>
											<?php $__currentLoopData = $UserMaster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($user->UserId); ?>"><?php echo e($user->UserName); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>
									</div>
								</div>
								<!--div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Finalized By:</label>
										<select name="FinalizedBy" class="form-control select2">
											<option value="0">--Select--</option>
											<?php $__currentLoopData = $UserMaster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($user->UserId); ?>"><?php echo e($user->UserName); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</select>
									</div>
								</div-->
								<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Date of form finalization:</label>
										<div class="row">
											<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
												<input type="date" name="FromfinalizationDate" class="form-control">
											</div>
											<div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
												<b>TO</b>
											</div>
											<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
												<input type="date" name="TofinalizationDate" class="form-control">
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
									<div class="form-group">
										<label>Calibration Date:</label>
										<div class="row">
											<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
												<input type="date" name="FromCalibrationDate" class="form-control">
											</div>
											<div class="col-lg-1 col-md-1 col-sm-12 col-xs-12">
												<b>TO</b>
											</div>
											<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
												<input type="date" name="ToCalibrationDate" class="form-control">
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin: 20px 0;">
									<button type="submit" class="btn btn-info pull-right" name="BtnSearch"><i class="fa fa-search mr7"></i>Search</button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</article>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<!-- your contents here -->
			</div>
		</div>
	</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JSscript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\calibration\resources\views/SummaryReport.blade.php ENDPATH**/ ?>