<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<title>Calibration Details Report</title>
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<link rel="shortcut icon" href="<?php echo e(asset('public/img/favicon/favicon.ico')); ?>" type="image/x-icon">
	<link rel="icon" href="<?php echo e(asset('public/img/favicon/favicon.ico')); ?>" type="image/x-icon">
	<style type="text/css">
		.table-bordered {
			border: 1px solid #ddd;
		}
		.table {
			width: 100%;
			max-width: 100%;
			margin-top: 20px;
			margin-bottom: 20px;
		}
		table {
			border-collapse: collapse;
			border-spacing: 0;
		}
		.table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, .table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, .table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th {
			border-top: 0;
		}
		.table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
			border-bottom-width: 2px;
		}
		.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
			border: 1px solid #ddd;
		}
		.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
			padding: 5px 8px;
			line-height: 1.42857143;
			vertical-align: top;
			border-top: 1px solid #ddd;
		}
		.mytable{
			width: 100%;
			max-width: 100%;
			/*font-size: 18px;*/
		}
		.mytable tr td, .mytable tr th{
			padding: 5px 8px;
			line-height: 1.42857143;
			vertical-align: top;
		}
		.mytable tr .UnderLine{
			padding-bottom: 3px;
			border-bottom: 2px solid #BDBDBD;
			font-weight: bold;
		}
	</style>
</head>
<body>
	<?php $__currentLoopData = $MainData['CalData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caldata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<table class="mytable" style="page-break-before: always;">
		<tr>
			<td><img src="<?php echo e(asset('public/img/logo.png')); ?>" alt="Calibration" style="width: 150px;"></td>
		</tr>
	</table>
	<table class="mytable">
		<tr>
			<td>Form ID : <span class="UnderLine"><?php echo e($caldata->FormId); ?></span></td>
			<td>Calibration Method : <span class="UnderLine"><?php echo e($caldata->CalibrationName); ?></span></td>
		</tr>
		<tr>
			<td>Instrument ID No : <span class="UnderLine"><?php echo e($caldata->InstrumentName); ?></span></td>
			<td>Device : <span class="UnderLine"><?php echo e($caldata->DeviceName); ?></span></td>
		</tr>
		<tr>
			<td>Make : <span class="UnderLine"><?php echo e($caldata->Make); ?></span></td>
			<td>Model : <span class="UnderLine"><?php echo e($caldata->Model); ?></span></td>
		</tr>
		<tr>
			<td>Weight box ID No : <span class="UnderLine"><?php echo e($caldata->WeightBoxId); ?></span></td>
			<td>Calibrated on : <span class="UnderLine"><?php echo e(date('d/m/Y',strtotime($caldata->CalibrationDate))); ?></span></td>
		</tr>
		<tr>
			<td>Next Calibrated on : <span class="UnderLine"><?php echo e(date('d/m/Y',strtotime($caldata->CalibrationNextDate))); ?></span></td>
			<td>Sprit level of Balance Checked (Yes/No) : <span class="UnderLine"><?php if($caldata->SpiritLevel==1): ?> <?php echo e("Yes"); ?> <?php elseif($caldata->SpiritLevel==2): ?> <?php echo e("No"); ?> <?php else: ?> <?php echo e(""); ?> <?php endif; ?></span></td>
		</tr>
		<tr>
			<td>Internal Calibration (Passes/Fails) : <span class="UnderLine"><?php if($caldata->Internal==1): ?> <?php echo e("Passes"); ?> <?php elseif($caldata->Internal==2): ?> <?php echo e("Fails"); ?> <?php else: ?> <?php echo e(""); ?> <?php endif; ?></span></td>
		</tr>
	</table>
	<?php 
	echo"Done".$caldata->DeviceTypeM;
	if($caldata->DeviceTypeM==1)
	{
		$DeviceTypeMM="gm";
	}
	elseif($caldata->DeviceTypeM==2)
	{
		$DeviceTypeMM="mg";	
	}
	else
	{
		$DeviceTypeMM=" ";
	}
	?>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Sr. No</th>
				<th>Standard Weight(<?php echo e($DeviceTypeMM); ?>)</th>
				<th>Certified Weight(A)(<?php echo e($DeviceTypeMM); ?>)</th>
				<th>Displayed Weight(B)(<?php echo e($DeviceTypeMM); ?>)</th>
				<th>Different Between A and B(<?php echo e($DeviceTypeMM); ?>)</th>
				<th>Acceptance Criteria(<?php echo e($DeviceTypeMM); ?>) of Certified Weight</th>
				<th>Result (Passes / Fails)</th>
			</tr>
		</thead>
		<tbody>
			<?php
			$CalLineData=DB::table('calibrationline')->where('RefRecId',$caldata->RecId)->orderBy('LineId', 'asc')->get();
			?>
			<?php $__currentLoopData = $CalLineData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($calline->LineId); ?></td>
				<td><?php echo e($calline->StWeight); ?></td>
				<td><?php echo e($calline->CertWeight); ?></td>
				<td><?php echo e($calline->DispWeight); ?></td>
				<td><?php echo e($calline->DiffWeight); ?></td>
				<td><?php echo e("± ".$calline->AccpWeight); ?></td>
				<td><?php if($calline->Result==1): ?><?php echo e('Passes'); ?><?php elseif($calline->Result==2): ?><?php echo e('Fails'); ?><?php else: ?><?php echo e(''); ?> <?php endif; ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<table class="mytable" style="margin-bottom: 20px;">
		<tr>
			<td style="width: 50%;">Performed by : 
				<span class="UnderLine">
					<?php
					if($caldata->PerformedBy!='')
					{
						$PerformedByName=DB::table('usermaster')->where('UserId',$caldata->PerformedBy)->get();
						echo $PerformedByName[0]->UserName;
					}
					?>
				</span>
			</td>
			<td>
				<?php if($caldata->Status=='20'): ?>
				Verified by: 
				<?php elseif($caldata->Status=='25'): ?>
				Decline (Verify) by : 
				<?php else: ?>
				Verified by: 
				<?php endif; ?>
				<span class="UnderLine">
					<?php
					if($caldata->VerifiedBy!='')
					{
						$VerifiedByName=DB::table('usermaster')->where('UserId',$caldata->VerifiedBy)->get();
						echo $VerifiedByName[0]->UserName;
					}
					?>
				</span>
			</td>
		</tr>
		<tr>
			<td>Date : <span class="UnderLine"><?php echo e(date('d/m/Y h:i A',strtotime($caldata->PerformDate))); ?></span></td>
			<td>Date : <span class="UnderLine"><?php if($caldata->VerifiedBy!=''): ?> <?php echo e(date('d/m/Y h:i A',strtotime($caldata->VerifiedDate))); ?> <?php endif; ?></span></td>
		</tr>
	</table>
	<table class="table table-bordered" style="border-width: 2px;">
		<tbody>
			<tr>
				<td style="width: 50%;">
					<?php if($caldata->Status=='30'): ?>
					Approved By : 
					<?php elseif($caldata->Status=='40'): ?>
					Decline by : 
					<?php else: ?>
					Approved By : 
					<?php endif; ?>
					<?php
					if($caldata->AproovelBy!='')
					{
						$AproovelByName=DB::table('usermaster')->where('UserId',$caldata->AproovelBy)->get();
						echo $AproovelByName[0]->UserName;
					}
					?>
				</td>
				<td>Date : <?php if($caldata->AproovelBy!=''): ?> <?php echo e(date('d/m/Y h:i A',strtotime($caldata->AproovelDate))); ?> <?php endif; ?></td>
			</tr>
		</tbody>
	</table>
	<div style="width: 100%;margin:20px 0;">
		<?php
		$CalLineData=DB::table('calibrationline')->where('RefRecId',$caldata->RecId)->orderBy('LineId', 'asc')->get();
		?>
		<?php $__currentLoopData = $CalLineData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<img src="<?php echo e(asset('public/Doc/'.$calline->Ifile.'')); ?>" style="width: 230px;" />
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<script type="text/javascript">
		window.print();
	</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\calibration\resources\views/DetailsReportData.blade.php ENDPATH**/ ?>