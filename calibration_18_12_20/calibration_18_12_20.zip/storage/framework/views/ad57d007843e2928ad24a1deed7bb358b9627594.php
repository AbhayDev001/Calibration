<?php $__env->startSection('content'); ?>
<div id="ribbon">
	<ol class="breadcrumb">
		<li>Home</li>
	</ol>
</div>
<div id="content">
	<section>
		<div class="row">
			<article class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div class="product-content product-wrap clearfix product-deatil" style="padding: 5px;background: #ecf0f5;">
					<div class="col-lg-12">
						<div class="row">
							<?php if(Session::has('failed')): ?>
							<div class="alert alert-danger alert-dismissible myalert">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<?php echo \Session::get('failed'); ?>

							</div>
							<?php endif; ?>
							<?php if(Session::has('success')): ?>
							<div class="alert alert-success alert-dismissible myalert">
								<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
								<?php echo \Session::get('success'); ?>

							</div>
							<?php endif; ?>
						</div>
						<div class="row mt10">
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="info-box">
									<span class="info-box-icon bg-aqua"><i class="fa fa-lg fa-fw fa-cube"></i></span>
									<div class="info-box-content">
										<span class="info-box-text">Total Calibration</span>
										<span class="info-box-number"><?php echo e($MainData['totcal']); ?></span>
									</div>
								</div>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="info-box">
									<span class="info-box-icon bg-aqua"><i class="fa fa-lg fa-fw fa-cube"></i></span>
									<div class="info-box-content">
										<a href="<?php echo e(url('/home/NewCalibration')); ?>">
											<span class="info-box-text">New Calibration</span>
											<span class="info-box-number"><?php echo e($MainData['newcal']); ?></span>
										</a>
									</div>
								</div>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="info-box">
									<span class="info-box-icon bg-green"><i class="fa fa-lg fa-fw fa-cube"></i></span>
									<div class="info-box-content">
										<a href="<?php echo e(url('/home/VerifiedCalibration')); ?>">
											<span class="info-box-text">Verified Calibration</span>
											<span class="info-box-number"><?php echo e($MainData['verifiedcal']); ?></span>
										</a>
									</div>
								</div>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="info-box">
									<span class="info-box-icon bg-yellow"><i class="fa fa-lg fa-fw fa-cube"></i></span>
									<div class="info-box-content">
										<a href="<?php echo e(url('/home/ApprovedCalibration')); ?>">
											<span class="info-box-text">Approved Calibration</span>
											<span class="info-box-number"><?php echo e($MainData['approvedcal']); ?></span>
										</a>
									</div>
								</div>
							</div>
						</div>
						<div class="row mt10">
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="info-box">
									<span class="info-box-icon bg-red"><i class="fa fa-lg fa-fw fa-cube"></i></span>
									<div class="info-box-content">
										<a href="<?php echo e(url('/home/DeclinedCalibration')); ?>">
											<span class="info-box-text">Declined Calibration</span>
											<span class="info-box-number"><?php echo e($MainData['declinedcal']); ?></span>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</article>
		</div>

		<?php if(isset($MainData["Calibration"])): ?>
		<div class="row">
			<div class="col-sm-12">
				<div class="table-responsive">
					<table id="datatable_fixed_column" class="table table-striped table-bordered table-hover" width="100%">
						<thead> 
							<tr>
								<th>
									<input type="text" class="form-control FillterData" placeholder="FormID" style="width: 100%;">
								</th>
								<th>
									<input type="text" class="form-control FillterData" placeholder="Calibrated" style="width: 100%;">
								</th>
								<th>
									<input type="text" class="form-control FillterData" placeholder="Instrument" style="width: 100%;">
								</th>
								<th>
									<input type="text" class="form-control FillterData" placeholder="Device" style="width: 100%;">
								</th>
								<th>
									<input type="text" class="form-control numeric FillterData" placeholder="Make" style="width: 100%;">
								</th>
								<th>
									<input type="text" class="form-control FillterData" placeholder="Model" style="width: 100%;">
								</th>
								<th>
									<input type="text" class="form-control FillterData" placeholder="Perform By" style="width: 100%;">
								</th>
								<th>
									<input type="text" class="form-control FillterData datepicker" data-dateformat="dd/mm/yy" placeholder="Perform Date" style="width: 100%;">
								</th>
								<th style="width: 100px;">
									<select class="form-control FillterData FillterStatus" style="width: 100%;">
										<option value="">All</option>
										<?php
										$StatusMaster=DB::table('statusmaster')->where('IsActive','1')->get();
										?>
										<?php $__currentLoopData = $StatusMaster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option><?php echo $status->Name; ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</th>
								<th></th>
							</tr>    
							<tr>
								<th><i class="fa fa-fw fa-user text-muted hidden-md hidden-sm hidden-xs"></i> FormID</th>
								<th><i class="fa fa-fw fa-user text-muted hidden-md hidden-sm hidden-xs"></i> Calibrated</th>
								<th><i class="fa fa-fw fa-phone text-muted hidden-md hidden-sm hidden-xs"></i> Instrument</th>
								<th><i class="fa fa-fw fa-user txt-color-blue hidden-md hidden-sm hidden-xs"></i> Device</th>
								<th><i class="fa fa-fw fa-user txt-color-blue hidden-md hidden-sm hidden-xs"></i> Make</th>
								<th><i class="fa fa-fw fa-user txt-color-blue hidden-md hidden-sm hidden-xs"></i> Model</th>
								<th><i class="fa fa-fw fa-user txt-color-blue hidden-md hidden-sm hidden-xs"></i> Perform By</th>
								<th><i class="fa fa-fw fa-user txt-color-blue hidden-md hidden-sm hidden-xs"></i> Perform Date</th>
								<th style="width: 120px;"><i class="fa fa-fw fa-user txt-color-blue hidden-md hidden-sm hidden-xs"></i> Status</th>
								<th style="width: 90px;">Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $MainData['Calibration']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caldata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($caldata->FormId); ?></td>
								<td><?php echo e($caldata->CalibrationName); ?></td>
								<td><?php echo e($caldata->InstrumentName); ?></td>
								<td><?php echo e($caldata->DeviceName); ?></td>
								<td><?php echo e($caldata->Make); ?></td>
								<td><?php echo e($caldata->Model); ?></td>
								<td>
									<?php
									$PerformedByName=DB::table('usermaster')->where('UserId',$caldata->PerformedBy)->get();
									echo $PerformedByName[0]->UserName;
									?>
								</td>
								<td><?php echo e(date("d/m/Y",strtotime($caldata->PerformDate))); ?></td>
								<td>
									<?php
									$StatusMaster=DB::table('statusmaster')->where('RecId',$caldata->Status)->first();
									echo $StatusMaster->Name;
									?>
								</td>
								<td>
									<?php if($caldata->CType==2): ?>
									<?php if($caldata->DeviceType==1): ?>
									<a href="<?php echo e(url('/ViewMonthlyCalibration/'.$caldata->RecId)); ?>" class="btn btn-xs btn-default"><i class="fa fa-eye"></i></a>
									<?php if(($caldata->Status==10 && $caldata->PerformedBy==Session::get('LoginData')['UserId'] && Session::get('LoginData')['Role']==2)): ?>
									<a href="<?php echo e(url('/EditMonthlyCalibration/'.$caldata->RecId)); ?>" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
									<?php endif; ?>
									<a href="<?php echo e(url('/PrintMonthlyCalibration/'.$caldata->RecId)); ?>" target="_blank" class="btn btn-xs btn-default"><i class="fa fa-print"></i></a>
									<?php else: ?>
									<a href="<?php echo e(url('/ViewMonthlyCalibrationMG/'.$caldata->RecId)); ?>" class="btn btn-xs btn-default"><i class="fa fa-eye"></i></a>
									<?php if(($caldata->Status==10 && $caldata->PerformedBy==Session::get('LoginData')['UserId'] && Session::get('LoginData')['Role']==2)): ?>
									<a href="<?php echo e(url('/EditMonthlyCalibrationMG/'.$caldata->RecId)); ?>" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
									<?php endif; ?>
									<a href="<?php echo e(url('/PrintMonthlyCalibrationMG/'.$caldata->RecId)); ?>" target="_blank" class="btn btn-xs btn-default"><i class="fa fa-print"></i></a>
									<?php endif; ?>
									<?php else: ?>
									<a href="<?php echo e(url('/ViewCalibration/'.$caldata->RecId)); ?>" class="btn btn-xs btn-default"><i class="fa fa-eye"></i></a>
									<?php if(($caldata->Status==10 && $caldata->PerformedBy==Session::get('LoginData')['UserId'] && Session::get('LoginData')['Role']==2)): ?>
									<a href="<?php echo e(url('/EditCalibration/'.$caldata->RecId)); ?>" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
									<?php endif; ?>
									<a href="<?php echo e(url('/PrintCalibration/'.$caldata->RecId)); ?>" target="_blank" class="btn btn-xs btn-default"><i class="fa fa-print"></i></a>
									<?php endif; ?>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		<?php endif; ?>
	</section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JSscript'); ?>						
<script src="<?php echo e(asset('public/js/plugin/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/plugin/datatables/dataTables.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/plugin/datatables/dataTables.tableTools.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/plugin/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/plugin/datatable-responsive/datatables.responsive.min.js')); ?>"></script>
<script type="text/javascript">
	$(document).ready(function() {
		var responsiveHelper_datatable_fixed_column = undefined;
		var breakpointDefinition = {
			tablet : 1024,
			phone : 480
		};

		var table = $('#datatable_fixed_column').DataTable({
			"bFilter": true,
			"bInfo": true,
			"bLengthChange": true,
			"bAutoWidth": true,
			"bPaginate": true,
			"bSort": true,
			"bStateSave": false,
			"sDom": "<'dt-toolbar'<'col-xs-12 col-sm-6'f><'col-sm-6 col-xs-12 hidden-xs'l>r>" +
			"t" +
			"<'dt-toolbar-footer'<'col-sm-6 col-xs-12 hidden-xs'i><'col-xs-12 col-sm-6'p>>",
			"autoWidth": true,
			"oLanguage": {
				"sSearch": '<span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>'
			},
			"preDrawCallback": function () {
				if (!responsiveHelper_datatable_fixed_column) {
					responsiveHelper_datatable_fixed_column = new ResponsiveDatatablesHelper($('#datatable_fixed_column'), breakpointDefinition);
				}
			},
			"rowCallback": function (nRow) {
				responsiveHelper_datatable_fixed_column.createExpandIcon(nRow);
			},
			"drawCallback": function (oSettings) {
				responsiveHelper_datatable_fixed_column.respond();
			}
		});

		$(".dataTables_filter").hide();
		$("#datatable_fixed_column thead th .FillterData").on( 'keyup change', function () {
			table.column( $(this).parent().index()+':visible' ).search( this.value ).draw();

		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\Calibration\resources\views/AdminHome.blade.php ENDPATH**/ ?>